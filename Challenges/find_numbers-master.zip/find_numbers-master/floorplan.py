from direct.showbase.ShowBase import ShowBase
from panda3d.core import loadPrcFile
import sys
loadPrcFile('conf.prc')

class FloorPlan(ShowBase):


    def __init__(self):
        super().__init__()
        self.cam.setPos(0, -40, 5)
        self.setBackgroundColor(0, 0, 0, 1)
        self.house = self.loader.loadModel('./floorplan.glb')
        self.house.setH(265)
        self.house.reparentTo(self.render)
        self.accept('q', self.quit_program)


    def quit_program(self):
        sys.exit(0)


game = FloorPlan()
game.run()